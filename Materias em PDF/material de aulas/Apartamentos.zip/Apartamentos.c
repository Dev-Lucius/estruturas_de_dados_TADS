#include "Apartamentos.h"

void cadastraApartamento(Apartamento *novo);

void mostraDadosApartamento(Apartamento ap)
{
    printf("\n ------------------------------------------------------------------------");
    printf("\n\t Condomínio %s ", ap.condominio);
    printf("\n\t Apartamento n° = %d", ap.num);
    printf("\n\t Andar= %d box= %d n°_comodos = %d  ", ap.andar, ap.box, ap.qtd_comodos);
    printf("\n\t Valor Aluguel = %.2f Valor Condomínio= %.2f ", ap.v_aluguel, ap.v_condominio);
    printf("\n ------------------------------------------------------------------------\n");
}