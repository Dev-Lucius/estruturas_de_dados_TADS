#ifndef APARTAMENTO_H
#define APARTAMENTO_H
#include <stdio.h>
#include <stdlib.h>
#include <locale.h> /*permite acentuação*/

// =====================
// Estruturas
// =====================

typedef struct
{
    char condominio[30];
    int num, andar, qtd_comodos, box;
    double v_aluguel, v_condominio;
} Apartamento;

void cadastraApartamento(Apartamento *novo);

void mostraDadosApartamento(Apartamento ap);

#endif