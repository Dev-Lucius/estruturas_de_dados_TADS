
#include "Apartamentos.h"

int main()
{
    printf("\n****** Início da Programa Apartamento  *******\n");

    Apartamento ap101 = {"Casa_Nova", 101, 1, 2, 56, 200.00, 100.00};

    mostraDadosApartamento(ap101);

    printf("\n****** Fim do Programa Apartamento  *******\n\n");
    exit(0);
}