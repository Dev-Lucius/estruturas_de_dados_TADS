#include "Apartamentos.h"

// void cadastraApartamento(Apartamento *novo);

void mostraDadosApartamento(Apartamento ap)
{
    printf("\n ------------------------------------------------------------------------");
    printf("\n\t Condomínio %s ", ap.condominio);
    printf("\n\t Apartamento n° = %d", ap.num);
    printf("\n\t Andar= %d box= %d n°_comodos = %d  ", ap.andar, ap.box, ap.qtd_comodos);
    printf("\n\t Valor Aluguel = %.2f Valor Condomínio= %.2f ", ap.v_aluguel, ap.v_condominio);
    printf("\n ------------------------------------------------------------------------\n");
}

void alteraAluguelEm10Porcento(Apartamento *ap)
{
    ""
    "Aumentar em 10 porcento o valor do aluguel"
    "";
    ap->v_aluguel += ap->v_aluguel * 0.2;
}

Apartamento *cadastraApartamento(char cond[], int num, int box)
{
    ""
    " Alocar memoria para um apartamento e retorna estrutura Apartamento"
    "";
    Apartamento *novo = (Apartamento *)malloc(sizeof(Apartamento));
    strcpy(novo->condominio, cond);
    novo->num = num;
    novo->box = box;
    novo->qtd_comodos = 0;
    novo->andar = 0;
    novo->v_aluguel = 0.0;
    novo->v_condominio = 0.0;
    return novo;
}

int retornaBoxApartamento(Apartamento ap)
{
    return ap.box;
}

void alteraBoxApartamento(Apartamento *ap)
{
    printf("\n Informe o número do Box:");
    scanf("%d", &ap->box);
}

void alteraBoxApartamento2(Apartamento *ap, int box)
{
    ap->box = box;
}

void cadastraProprietario(Proprietario **novo, char nome[], char cpf[])
{
    *novo = (Proprietario *)malloc(sizeof(Proprietario));
    strcpy((*novo)->nome, nome);
    strcpy((*novo)->cpf, cpf);
}

void comprarApartamento(Apartamento *ap, Proprietario *comprador, Data dt)
{
    ap->dono = comprador;
    ap->dtCompra = dt;
}