#ifndef APARTAMENTO_H
#define APARTAMENTO_H
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <locale.h> /*permite acentuação*/

// =====================
// Estruturas
// =====================

typedef struct
{
    char nome[30];
    char cpf[14];
} Proprietario;

typedef struct
{
    int dia, mes, ano;
} Data;

typedef struct
{
    char condominio[30];
    int num, andar, qtd_comodos, box;
    double v_aluguel, v_condominio;
    Proprietario *dono;
    Data dtCompra;
} Apartamento;

Apartamento *cadastraApartamento(char cond[], int num, int box);
void cadastraProprietario(Proprietario **novo, char nome[], char cpf[]);
void alteraAluguelEm10Porcento(Apartamento *ap);
void mostraDadosApartamento(Apartamento ap);
int retornaBoxApartamento(Apartamento ap);
void alteraBoxApartamento(Apartamento *ap);
void alteraBoxApartamento2(Apartamento *ap, int box);
void comprarApartamento(Apartamento *ap, Proprietario *comprador, Data dt);

#endif