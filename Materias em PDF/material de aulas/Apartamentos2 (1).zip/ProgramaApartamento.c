
#include "Apartamentos.h"

int main()
{
    printf("\n****** Início da Programa Apartamento  *******\n");

    Apartamento ap101 = {"Casa_Nova", 101, 1, 2, 56, 200.00, 100.00, NULL, {1, 1, 1}};
    Apartamento ap102 = {"Casa_Nova", 102, 1, 2, 57, 250.00, 120.00, NULL, {2, 2, 2022}};

    mostraDadosApartamento(ap102);

    // aumentar o valor do aluguel do AP 101 em 10%
    alteraAluguelEm10Porcento(&ap101);
    mostraDadosApartamento(ap101);

    // declarar dois ponteiros
    Apartamento *ap301, *ap401;

    // alocar memoria e preencher os APTO
    ap301 = cadastraApartamento("BGV", 301, 23);
    ap401 = cadastraApartamento("BGV", 401, 32);

    // Mostrar os dados dos APTO
    mostraDadosApartamento(*ap301);
    mostraDadosApartamento(*ap401);

    printf("\n O Box do Apartamento %d é o número %d \n", ap101.num, retornaBoxApartamento(ap101));
    // Alterar o box do AP101
    alteraBoxApartamento(&ap101);

    printf("\n O Box do Apartamento %d é o número %d \n", ap101.num, retornaBoxApartamento(ap101));

    // Alterar o box do AP101 para 33
    alteraBoxApartamento2(&ap101, 33);
    printf("\n O Box do Apartamento %d é o número %d \n", ap101.num, retornaBoxApartamento(ap101));

    printf("\n****** Fim do Programa Apartamento  *******\n\n");

    Proprietario *luis;

    cadastraProprietario(&luis, "Luis", "234.567.890-23");

    printf("\n Proprietario nome %s, CPF= %s \n", luis->nome, luis->cpf);

    Data hj = {17, 3, 2026};
    comprarApartamento(ap301, luis, hj);

    mostraDadosApartamento(*ap301);

    exit(0);
}