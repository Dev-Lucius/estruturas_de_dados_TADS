#include <stdio.h>
#include <stdlib.h>

void troca2(int *pa, int *pb){
    int temp;
    temp = *pa;
    *pa = *pb;
    *pb = temp;
}


int main(){

    printf("\n Passagem por Referẽncia Exemplo");
    int x = 10, y = 20;
    
    printf("\n X = %d e Y = %d \n",x,y);
    troca2(&x, &y);
    printf("\n X = %d e Y = %d \n",x,y);


}

