#include <stdio.h>
#include <stdlib.h>

void imprimeVetor(int vt[], int n){
    for(int i=0;i<n;i++)
        printf(" vt[%d]=%d\n",i,vt[i]);
    printf("\n");   
}


void imprimeVetorPonteiro(int *p, int n){
   
    for(int i=0;i<n;i++)
        printf(" vt[%d]=%d\n",i,*(p+i));   
    printf("\n");
}

int main(){
    int v[5] = {3,4,5,2,1}, n=5;
    printf("\n Uso da função imprimeVetor passagem do próprio vetor.\n");
    imprimeVetor(v,n);

    printf("\n Uso da função imprimeVetorPonteiro passagem do ponteiro do vetor.\n");
    imprimeVetorPonteiro(v,n);
    
}


