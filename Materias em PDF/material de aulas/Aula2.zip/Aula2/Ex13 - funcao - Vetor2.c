#include <stdio.h>
#include <stdlib.h>

void imprimeVetor(int vt[],int n){
    for(int i=0;i<n;i++)
        printf(" vt[%d]=%d\n",i,vt[i]);
    printf("\n");   
}


void imprimeVetorPonteiro(int *p,int n){
    for(int i=0;i<n;i++)
        printf(" vt[%d]=%d\n",i,*(p+i));   
    printf("\n");
}

void somaDez(int vt[], int n ){
    printf("\n Soma 10 ao vetor\n");
    for(int i=0;i<n;i++)
        vt[i] += 10;   
}

int main(){
    int v[5] = {3,4,5,2,1}, n=5;
    imprimeVetor(v,n);
    imprimeVetorPonteiro(v,n);
    
    //altera o vetor, somando 10 a cada elemento do vetor
    somaDez(v,n);
    imprimeVetor(v,n);




    
}


