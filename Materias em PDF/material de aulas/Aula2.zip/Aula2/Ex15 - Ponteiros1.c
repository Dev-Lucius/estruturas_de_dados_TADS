#include <stdio.h>
#include <stdlib.h>


int main(){

    int x = 10;
    int *px, **ppx;

    px = &x;
    ppx = &px;
    
    printf("\n Valor de X = %d",x);
    printf("\n Valor de *PX = %d",*px);
    printf("\n Valor de *PPX = %d",**ppx);

    printf("\n Endereco de X = %p",&x);
    printf("\n Endereco de *PX = %p",&px);
    printf("\n Endereco de *PPX = %p",&ppx);

    printf("\n Conteudo de *PX = %p",px);
    printf("\n Conteudo de *PPX = %p",ppx);

    printf("\n Conteudo referenciado *PX = %d",*px);
    printf("\n Conteudo referenciado *PPX = %d\n",**ppx);


}

