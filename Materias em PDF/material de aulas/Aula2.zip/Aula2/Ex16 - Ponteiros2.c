#include <stdio.h>
#include <stdlib.h>

int main()
{

    int x = 10, y = 20;
    int *px, *py, **ppx;

    px = &x;
    py = &y;
    ppx = &px; // ppx recebe o endereço do ponteiro px

    printf("\n Valor de X = %d", x);
    printf("\n Valor de *PX = %d", *px);
    printf("\n Valor de *PPX = %d", **ppx);

    ppx = &py; // ppx recebe o endereço do ponteiro py

    printf("\n Conteudo referenciado *PX = %d", *px);
    printf("\n Conteudo referenciado *PPX = %d\n", **ppx);
}
