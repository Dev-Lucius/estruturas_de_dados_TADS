#include <stdio.h>
#include <stdlib.h>

int main()
{

    int x = 10, y = 20;
    int *px, *py, **ppx;

    px = &x;
    py = &y;
    ppx = &px;

    printf("\n Valor de X = %d", x);
    printf("\n Valor de *PX = %d", *px);
    printf("\n Valor de *PPX = %d", **ppx);

    ppx = &py;

    printf("\n Conteudo referenciado *PX = %d", *px);
    printf("\n Conteudo referenciado *PPX = %d\n", **ppx);

    //*py = 50; //Equivale y= 50
    **ppx = 50; // Equivale y= 50

    printf("\n Valor de X = %d Y = %d", x, y);
    printf("\n Valor de *PY = %d", *py);
    printf("\n Valor de *PPX = %d\n", **ppx);
}
