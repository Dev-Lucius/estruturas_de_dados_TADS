#include <stdio.h>
#include <stdlib.h>

int main()
{
    int x = 10, y = 50;  // variavel
    int *px, *py, **ppx; // declaracao dos ponteiros

    px = &x; // atribuicao do endereço x aos ponteiros
    py = &y;
    ppx = &px; // ponteiro de ponteiro

    printf("\n Valor x = %d e y = %d", x, y);
    printf("\n Valor px = %d e py = %d", *px, *py);
    printf("\n Valor ppx = %d", **ppx);

    // troca ponteiro ppx recebe o endereço do ponteiro py

    ppx = &py;

    printf("\n Valor x = %d e y = %d", x, y);
    printf("\n Valor px = %d e py = %d", *px, *py);
    printf("\n Valor ppx = %d\n", **ppx);

    // acrescentar 15 ao conteúdo apontado pelo **ppx =50;
    **ppx = **ppx + 15;
    printf("\n Valor x = %d e y = %d", x, y);
    printf("\n Valor px = %d e py = %d", *px, *py);
    printf("\n Valor ppx = %d\n", **ppx);

    // acrescentar 15 ao conteúdo apontado pelo *ppx = py;
    *ppx = *ppx + 15;
    printf("\n Valor x = %d e y = %d", x, y);
    printf("\n Valor px = %d e py = %d", *px, *py);
    printf("\n Valor ppx = %d\n", **ppx);
}
