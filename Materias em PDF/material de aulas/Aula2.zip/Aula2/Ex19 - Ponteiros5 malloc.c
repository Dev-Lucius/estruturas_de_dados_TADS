#include <stdio.h>
#include <stdlib.h>


void locaAtribuiValor(int **p){
    *p = (int *)malloc(sizeof(int));
    **p = 100;
}



int main(){

    int *px;
    printf("O ponteiro px, precisa receber um valor de retorno de uma função:\n");
    locaAtribuiValor(&px);
    
    printf("\n Valor de *PX = %d \n",*px);
    free(px);

}

