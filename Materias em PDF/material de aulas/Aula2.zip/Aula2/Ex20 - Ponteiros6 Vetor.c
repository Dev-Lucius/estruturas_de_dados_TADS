#include <stdio.h>
#include <stdlib.h>


void imprimeVetor(int vt[],int n){
    printf("\n Vetor normal \n");
    for(int i=0;i<n;i++)
        printf(" vt[%d]=%d",i,vt[i]);
    printf("\n");   
}

//cria um novo vetor dinâmico e retorna a referencia do vetor
int *criaVetor(int n){
    int *p = (int *)malloc(n * sizeof(int));
    for(int i=0;i<n;i++)
        p[i] = i*10;
    return p;
}

//Alocacao estática - ERRO o Vetor Termina com a Função
int *criaVetor2(int n){
    int v[5];
    for(int i=0;i<n;i++)
        v[i] = i*10;
    return v;
}

int main(){

    int *px;
    
    px = criaVetor(5);
    imprimeVetor(px, 5);
    //free(px);
    //imprimeVetor(px, 5);

}

