#include <stdio.h>
#include <stdlib.h>


void imprimeVetor(int *vt,int n){
    printf("\n Vetor Ponteiro \n");
    for(int i=0;i<n;i++)
        printf(" vt[%d]=%d",i,*(vt+i));
    printf("\n");   
}

//cria um novo vetor dinâmico e retorna a referencia do vetor
void criaVetor(int **px, int n){
    for(int i=0;i<n;i++){
        *(px+i) = (int*)malloc(sizeof(int));
        *((*px)+i) = i*10;
    }
}


int main(){
    //vetor com 5 posições de ponteiro de inteiro
    int *vx[5];
    
    criaVetor(vx,5);
    imprimeVetor(*vx, 5);
    //free(px);
    //imprimeVetor(px, 5);

}

