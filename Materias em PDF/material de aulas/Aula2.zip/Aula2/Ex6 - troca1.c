#include <stdio.h>
#include <stdlib.h>

int main()
{
    int x, *px, y, *py, aux;

    x = 10;
    y = 20;

    px = &x;
    py = &y;

    printf("\n X = %d e Y = %d", x, y);

    printf("\n Troca dos valores de X e Y");
    aux = x;   // auxiliar para troca
    *px = y;   // troca o valor do ponteiro px = x
    *py = aux; // troca o valor do ponteiro py = y

    printf("\n X = %d e Y = %d \n", x, y);
}
