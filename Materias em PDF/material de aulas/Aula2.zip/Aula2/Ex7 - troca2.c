#include <stdio.h>
#include <stdlib.h>

int main()
{
    int x, *px, y, *py, aux;

    x = 10;
    y = 20;

    printf("\n X = %d e Y = %d", x, y);
    aux = x;
    px = &x;
    py = &y;

    // troca de valores das variáveis a partir dos ponteiros, copia o conteúdo do ponteiro
    x = *py;
    y = aux;

    printf("\n X = %d e Y = %d\n", x, y);
    printf("\n *pX = %d e *pY = %d\n", *px, *py);
}
