#include <stdio.h>
#include <stdlib.h>

int main()
{
    int x = 10, y = 50; // variavel
    int *px;            // declaracao do ponteiro

    px = &x; // atribuicao do endereço ao ponteiro

    printf("\n Valor de x = %d endereco de      x = %p", x, &x);
    printf("\n Valor de px= %d end. armazenado px = %p\n", *px, px); // consulta referenciada

    *px = *px + 25;

    printf("\n Valor de x = %d", x);
    printf("\n Valor referenciado por px = %d\n", *px);

    px = &y; // copiando o endereço de Y para px
    printf("\n Valor de x = %d", x);
    printf("\n Valor de y = %d", y);
    printf("\n Valor de *px = %d\n", *px);

    // qual valor px = ?, x = 35, y= 50 equivale y = x + y
    *px = x + y; 
    
    printf("\n Valor de x = %d", x);
    printf("\n Valor de y = %d", y);
    printf("\n Valor de *px = %d\n", *px);


}
