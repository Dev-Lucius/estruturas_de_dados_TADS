#include <stdio.h>
//Estrutura Pessoa
struct pessoa{
    int cod;
    char nome [15];
    char sobrenome [20];
    int idade;
    char telefone [10];
};

int main(){
    //DECLARAÇÃO Vetor de STRUCT
    struct pessoa ListaConvidados[20];

    for(int i=0; i<2; i++){
        ListaConvidados[i].cod = i+1;
        printf("Digite o nome do convidado: ");
        scanf("%s", &ListaConvidados[i].nome);
        printf("Digite o sobrenome do convidado: ");
        scanf("%s", &ListaConvidados[i].sobrenome);
        printf("Digite a idade do convidado: ");
        scanf("%d", &ListaConvidados[i].idade);
        printf("Digite o telefone do convidado: ");
        scanf("%s", &ListaConvidados[i].telefone);
    }

    for(int i=0; i<2; i++){
        printf("\n\nCodigo: %d", ListaConvidados[i].cod);
        printf("\nNome: %s", ListaConvidados[i].nome);
        printf("\nSobrenome: %s", ListaConvidados[i].sobrenome);
        printf("\nIdade: %d", ListaConvidados[i].idade);
        printf("\nTelefone: %s", ListaConvidados[i].telefone);
    }   
}
