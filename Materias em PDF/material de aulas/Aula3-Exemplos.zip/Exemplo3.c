#include <stdio.h>
struct pessoa{
    int cod; 
    char nome [15];
    char sobrenome [20];
    int idade;
    char telefone [10];
    char tipo [10];
};
//NOVA DEFINIÇÃO PARA PESSOA
typedef struct pessoa Pessoa;

int main()
{
    //DECLARAÇÃO DOS NOVOS TIPOS Cliente e Fornecedor 
    Pessoa joao, maria = {2,"Maria","Aparecida",23,"45433333","Cliente"};

    //ATRIBUIÇÃO DE VALORES
    joao.cod = 1;
    joao.idade = 30;
    strcpy(joao.nome,"Joao Carlos");
    strcpy(joao.sobrenome, "Farias");
    strcpy(joao.telefone, "1212454533");
    strcpy(joao.tipo, "Cliente"); 

    //SAÍDA DOS VALORES ARMAZENADOS NA STRUCT
    printf("\n%s:\n\t Nome: %s  %s \n",joao.tipo,joao.nome,joao.sobrenome);
    printf("\tCodigo: %d  e idade %d \n",joao.cod,joao.idade);
    printf("\tTelefone: %s \n",joao.telefone);

    printf("\n%s:\n\t Nome: %s  %s\n",maria.tipo,maria.nome,maria.sobrenome);
    printf("\tCodigo: %d  e idade %d \n",maria.cod,maria.idade);
    printf("\tTelefone: %s \n\n",maria.telefone);
    return 0;
}