#include <stdio.h>
#include <locale.h> /*permite acentuação*/
#include <stdlib.h>

typedef struct pessoa
{
    int cod;
    char nome[15];
    char sobrenome[20];
    int idade;
    char telefone[10];
} Pessoa;

void mostrarDadosPessoa(Pessoa ps)
{ // PASSAGEM POR VALOR
    printf("\nPessoa:\n\t Nome: %s  %s \n", ps.nome, ps.sobrenome);
    printf("\tCodigo: %d  e idade %d \n", ps.cod, ps.idade);
    printf("\tTelefone: %s \n", ps.telefone);
}

void lerDadosPessoa(Pessoa *ps, int cod)
{ // PASSAGEM POR REFERENCIA (ponteiro)
    ps->cod = cod;
    printf("\nInfome seu nome:");
    scanf("%s", ps->nome);
    printf("\nInfome seu Sobrenome:");
    scanf("%s", ps->sobrenome);
    printf("\nInfome sua idade:");
    scanf("%d", &ps->idade);
    printf("\nInfome seu telefone:");
    scanf("%s", ps->telefone);
}

int main()
{
    system("clear");
    setlocale(LC_ALL, "");
    int codigo = 1;

    // declaração de um ponteiro de Cliente
    Pessoa *paulo;
    // inicialização do ponteiro;
    paulo = NULL;

    // Alocação dinâmica de memória para um STRUCT
    paulo = (Pessoa *)malloc(sizeof(Pessoa));

    paulo->cod = 1;
    paulo->idade = 30;
    strcpy(paulo->nome, "Paulo Cesar");
    strcpy(paulo->sobrenome, "Silva");
    strcpy(paulo->telefone, "343545443");

    mostrarDadosPessoa(*paulo); // passagem por valor

    // Liberar memória para reciclagem
    free(paulo);
    mostrarDadosPessoa(*paulo);
    exit(0);
}