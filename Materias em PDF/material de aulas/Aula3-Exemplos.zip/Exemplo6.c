#include <stdio.h>
#include <locale.h> /*para acentuação*/
#include <stdlib.h>

typedef struct endereco
{
    char nomeRua[15];
    int numero;
    int cep;
} Endereco;

typedef struct pessoa
{
    int cod;
    char nome[15];
    Endereco endereco; // Ligação entre as estruturas aninhadas
} Pessoa;

void mostrarDadosPessoa(Pessoa cli)
{
    printf("\nPessoa: %s  Código: %d \n", cli.nome, cli.cod);
    printf("Endereço: %s Número:%d Cep:%d \n", cli.endereco.nomeRua, cli.endereco.numero,
           cli.endereco.cep);
}

void lerDadosPessoa(Pessoa *cli, int cod)
{
    cli->cod = cod;
    printf("\nInfome seu nome:");
    scanf("%s", cli->nome);
    printf("\nInfome sua Rua:");
    scanf("%s", cli->endereco.nomeRua);
    printf("\nInfome Numero Casa:");
    scanf("%d", &cli->endereco.numero);
    printf("\nInfome seu CEP:");
    scanf("%d", &cli->endereco.cep);
}

int main()
{
    system("clear");
    setlocale(LC_ALL, "");
    Pessoa joao, maria; // duas Pessoas novas
    Endereco minhaCasa;
    joao.cod = 1;
    strcpy(joao.nome, "João Cesar");
    maria.cod = 2;
    strcpy(maria.nome, "Maria Cesar");
    strcpy(minhaCasa.nomeRua, "Rua 24 Maio");
    minhaCasa.numero = 332;
    minhaCasa.cep = 96500333;
    // associação entre Pessoa e endereco
    joao.endereco = minhaCasa;
    maria.endereco = minhaCasa;
    mostrarDadosPessoa(joao);
    mostrarDadosPessoa(maria);

    maria.endereco.numero = 500;
    mostrarDadosPessoa(joao);
    mostrarDadosPessoa(maria);
    exit(0);
}