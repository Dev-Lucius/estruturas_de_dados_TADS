#include <stdio.h>
#include <locale.h> /*alara acentuação*/
#include <stdlib.h>
#include <string.h>
typedef struct
{
    char nomeRua[15];
    int numero;
    char cep[10];
} Endereco;

typedef struct
{
    int cod;
    int idade;
    char nome[15];
    Endereco endereco;
} Pessoa;

typedef struct casal
{
    char data[10];
    Pessoa *marido; // dois ponteiros para Pessoas
    Pessoa *esposa;
} Casal;

Casal *matrimonio(Pessoa *p1, Pessoa *p2)
{
    Casal *c = (Casal *)malloc(sizeof(Casal));
    strcpy(c->data, "02/06/20");
    c->marido = p1;
    c->esposa = p2;
    return c;
}
void imprimeCertidaoCasamento(Casal cs)
{
    printf("\n\nCertidão de Casamento!\n");
    printf("\n Nada data %s Casaram-se neste cartório ", cs.data);
    printf("\n \t%s e %s", cs.marido->nome, cs.esposa->nome);
    printf("\n\n Dou fé a este Matrimonio!\n");
}
int main()
{
    system("clear");
    setlocale(LC_ALL, "");
    Pessoa joao, maria;
    joao.cod = 1;
    joao.idade = 30;
    strcpy(joao.nome, "Joao Carlos");
    strcpy(joao.endereco.nomeRua, "Duque de caxias");
    joao.endereco.numero = 54;
    strcpy(joao.endereco.cep, "96234-234");
    maria.cod = 2;
    maria.idade = 26;
    strcpy(maria.nome, "Maria Aparecida");
    strcpy(maria.endereco.nomeRua, "Duque de caxias");
    maria.endereco.numero = 45;
    strcpy(maria.endereco.cep, "96234-234");
    // matrimonio é o relacionamento entre duas pessoas
    Casal *joaoEmaria = matrimonio(&joao, &maria);
    imprimeCertidaoCasamento(*joaoEmaria);

    strcpy(joao.nome, "Joao Pedro");
    imprimeCertidaoCasamento(*joaoEmaria);

    free(joaoEmaria);
    exit(0);
}
