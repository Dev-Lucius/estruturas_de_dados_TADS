#include <stdio.h>
#include <locale.h> /*alara acentuação*/
#include <stdlib.h>
#include <string.h>
typedef struct
{
    char nomeRua[15];
    int numero;
    char cep[10];
} Endereco;

typedef struct
{
    int cod;
    int idade;
    char nome[15];
    Endereco endereco;
} Pessoa;

typedef struct casal
{
    char data[10];
    Pessoa *marido; // dois ponteiros para Pessoas
    Pessoa *esposa;
} Casal;

Casal *matrimonio(Pessoa *p1, Pessoa *p2)
{
    Casal *c = (Casal *)malloc(sizeof(Casal));
    strcpy(c->data, "02/06/20");
    c->marido = p1;
    c->esposa = p2;
    return c;
}

void cadastraPessoa(Pessoa *ps, int cod)
{
    ps->cod = cod;
    printf("\n Cadastra Pessoa. Informe o nome:");
    scanf("%s", ps->nome);
    printf("Informe Idade:");
    scanf("%d", &ps->idade);
    printf("Rua:");
    scanf("%s", ps->endereco.nomeRua);
    printf("Rua numero:");
    scanf("%d", &ps->endereco.numero);
    printf("Cep:");
    scanf("%s", ps->endereco.cep);
}

void imprimePessoa(Pessoa ps)
{
    printf("\n Pessoa: \nNome: %s", ps.nome);
    printf("\n Endereco:%s,%d e Telefone=%d \n", ps.endereco.nomeRua, ps.endereco.numero, ps.idade);
}

void imprimeCertidaoCasamento(Casal cs)
{
    printf("\n\nCertidão de Casamento!\n");
    printf("\n Nada data %s Casaram-se neste cartório ", cs.data);
    printf("\n \t%s e %s", cs.marido->nome, cs.esposa->nome);
    printf("\n\n Dou fé a este Matrimonio!\n");
}

int main()
{
    system("clear");
    setlocale(LC_ALL, "");
    int num = 1;
    // vetor para armazenar 4 Pessoas
    Pessoa vetorPessoas[4];

    // Ponteiro para uma struct Pessoa
    // Pessoa *ponteiroPessoa;

    vetorPessoas[0].cod = num++;
    vetorPessoas[0].idade = 30;
    strcpy(vetorPessoas[0].nome, "Joao Carlos");
    strcpy(vetorPessoas[0].endereco.nomeRua, "Duque de caxias");
    vetorPessoas[0].endereco.numero = 54;
    strcpy(vetorPessoas[0].endereco.cep, "96234-234");
    vetorPessoas[1].cod = num++;
    vetorPessoas[1].idade = 26;
    strcpy(vetorPessoas[1].nome, "Maria Aparecida");
    strcpy(vetorPessoas[1].endereco.nomeRua, "Duque de caxias");
    vetorPessoas[1].endereco.numero = 45;
    strcpy(vetorPessoas[1].endereco.cep, "96234-234");
    // matrimonio é o relacionamento entre duas pessoas
    Casal *joaoEmaria = matrimonio(vetorPessoas, vetorPessoas + 1);
    imprimeCertidaoCasamento(*joaoEmaria);

    cadastraPessoa(&vetorPessoas[2], num++);
    cadastraPessoa(&vetorPessoas[3], num++);

    for (int i = 0; i < 5; i++)
    {
        imprimePessoa(vetorPessoas[i]);
    }

    free(joaoEmaria);
    exit(0);
}
