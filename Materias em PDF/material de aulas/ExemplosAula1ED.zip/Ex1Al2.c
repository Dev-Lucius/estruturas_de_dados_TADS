#include <stdio.h>

int main()
{
    int soma = 10;
    float money = 2.21;
    char letra = 'A';
    double pi = 3.1415E6;

    printf("\n Valor da Soma = %d ", soma);
    printf("\n valor de Money = %f", money);
    printf("\n valor da Letra = %c e o codigo ASC = %d", letra, letra);
    printf("\n valor de Pi = %e \n", pi);
    return 0;
}