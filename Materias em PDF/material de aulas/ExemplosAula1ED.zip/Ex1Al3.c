#include <stdio.h>

int main()
{
    int idade;

    printf("\n Informe sua Idade = ");
    scanf("%d", &idade);
    printf(" Sua idade é = %d \n", idade);
    return 0;
}