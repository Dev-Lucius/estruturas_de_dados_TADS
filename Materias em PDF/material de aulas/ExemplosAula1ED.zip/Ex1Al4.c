#include <stdio.h>

int main()
{
    char ch;
    printf("\n Digite um caracter: ");
    scanf("%c", &ch);
    printf(" %c = %d em decimal e ASC ", ch, ch);
    printf("\n %c = %o em octal,\n %c = %x em hexadecimal\n", ch, ch, ch, ch);

    return 0;
}