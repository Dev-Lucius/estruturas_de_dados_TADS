#include <stdio.h>

int main()
{
    // Printar a table a Asc

    for (int i = 48; i < 128; i++)
        printf("\n Letra %c  - código Asc =  %d ", i, i);
    printf("\n");

    return 0;
}