#include <stdio.h>

int main()
{
    int idade, idade2;

    printf("\n Informe sua idade:");          // saída
    scanf("%d", &idade);                      // entrada de dados
    printf("\n Informe idade do seu Irmão:"); // saída
    scanf("%d", &idade2);

    printf("\n Sua idade é: %d, idade seu irmão é = %d", idade, idade2);

    printf("\n Sua idade está armazenada na posição de memória = %x", &idade);
    printf("\n Sua idade2 está armazenada na posição de memória = %x \n\n", &idade2);
    return 0;
}