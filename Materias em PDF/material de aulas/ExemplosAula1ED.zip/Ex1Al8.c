#include <stdio.h>

int main()
{
    float a = 35.1111111111111111;
    float b = 35.1111111111111111;
    float c = a + b;

    printf("\n A = %4.20f", a);
    printf("\n B = %4.20f", b);
    printf("\n C = %4.20f\n", c);

    double da = 35.1111111111111111;
    double db = 35.1111111111111111;
    double dc = da + db;

    printf("\n A = %4.20f", da);
    printf("\n B = %4.20f", db);
    printf("\n C = %4.20f\n", dc);
    return 0;
}