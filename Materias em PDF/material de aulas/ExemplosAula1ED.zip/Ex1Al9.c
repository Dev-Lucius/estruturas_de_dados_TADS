#include <stdio.h>

int main()
{
    // declaração de variáveis
    char nome[20];
    int idade;
    float salario;
    double media;
    char letra;

    printf("\n Digite seu nome: ");
    scanf("%s", nome);
    printf("\n Informe sua Idade: ");
    scanf("%d", &idade);
    printf("Digite seu Salario: ");
    scanf("%f", &salario);
    fflush(stdout);

    printf("\n Nome: %s Endereco = %x", nome, &nome);
    printf("\n Idade = %d Endereco = %x", idade, &idade);
    printf("\n Salario = %.2f Endereco = %x", salario, &salario);
    printf("\n Letra = %c \n Endereco = %x \n", nome[0], &nome[0]);

    return 0;
}