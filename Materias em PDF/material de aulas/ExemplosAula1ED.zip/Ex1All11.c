#include <stdio.h>

int main()
{
    int a = 0;
    float b = 10.04f;
    char c = 'D';
    double d = 12.565;

    printf("\n Tamanho de um inteiro é = %d bytes", sizeof(a));
    printf("\n Tamanho de um float é = %d bytes", sizeof(b));
    printf("\n Tamanho de um char é = %d bytes", sizeof(c));
    printf("\n Tamanho de um double é = %d bytes\n\n", sizeof(d));

    return 0;
}