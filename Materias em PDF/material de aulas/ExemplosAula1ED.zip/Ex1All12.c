#include <stdio.h>

int main()
{
    int a = 2;
    (a == 0) ? printf("\n A é igual a Zero!\n")
             : printf("\n A é diferente de Zero!\n");

    a = 0;

    (a == 0) ? printf("\n A é igual a Zero!\n")
             : printf("\n A é diferente de Zero!\n");

    return 0;
}