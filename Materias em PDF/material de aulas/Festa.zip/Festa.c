#include "Festa.h"

// =====================
// Funções de Cadastro
// =====================

int cadastraConvidado(Festa *festa)
{
    if (festa->totalConvidados >= 50)
    {
        printf("Limite de convidados\n");
        return 0;
    }
    Convidado convidado;
    convidado.codigo = festa->totalConvidados + 1;
    printf("Digite o nome do convidado: ");
    scanf(" %[^\n]", convidado.nome);

    printf("Digite o telefone do convidado: ");
    scanf(" %[^\n]", convidado.telefone);

    convidado.confirmou = 0;
    festa->convidados[festa->totalConvidados] = convidado;
    festa->totalConvidados++;

    return 1;
}

int cadastraTrabalhador(Festa *festa)
{
    if (festa->totalTrabalhadores >= 20)
    {
        printf("Limite de trabalhadores\n");
        return 0;
    }
    Trabalhador trabalhador;
    trabalhador.codigo = festa->totalTrabalhadores + 1;
    printf("Digite o nome do trabalhador: ");
    scanf(" %[^\n]", trabalhador.nome);

    printf("Digite a funcao do trabalhador: ");
    scanf(" %[^\n]", trabalhador.funcao);

    printf("Digite o pagamento do trabalhador: ");
    scanf("%f", &trabalhador.pagamento);

    festa->trabalhadores[festa->totalTrabalhadores] = trabalhador;
    festa->totalTrabalhadores++;

    return 1;
};

int criarConvite(Festa *festa)
{
    int codigoConvidado;
    printf("Digite o codigo do convidado: ");
    scanf("%d", &codigoConvidado);

    int indice = buscarConvidado(festa, codigoConvidado);
    if (indice == -1)
    {
        printf("Convidado nao encontrado!\n");
        return 0;
    }

    Convite novo;
    novo.codigo=festa->totalConvites + 1;

    printf("Digite a mensagem do convite: ");
    scanf(" %[^\n]", novo.mensagem);

    novo.convidado = &festa->convidados[indice];
    festa->convites[festa->totalConvites] = novo;
    festa->totalConvites++;

    return 1;
}

// void cadastraFesta(Festa *festa)
// {   
//     printf("Digite o nome da festa: ");
//     scanf(" %s", festa->nome);
//     printf("Digite o local da festa: ");
//     scanf(" %s", festa->local);

//     printf("Digite a data da festa: ");
//     scanf("%d/%d/%d", &festa->data.dia, &festa->data.mes, &festa->data.ano);
//     printf("Digite o horario da festa: ");
//     scanf("%d:%d", &festa->horario.hora, &festa->horario.minuto);

//     festa->totalConvidados = 0;
//     festa->totalTrabalhadores = 0;
//     festa->totalConvites = 0;
// };
// // incliuir a data, local,

// // =====================
// // Funções de Operação
// // =====================

int confirmarPresenca(Festa *festa)
{
    int codigo;
    printf("Digite o codigo do convidado a confirmar:");
    scanf("%d", &codigo);

    int convidado = buscarConvidado(festa, codigo);
    if (convidado == -1)
    {
        printf("Convidado nao encontrado!\n");
        return 0;
    }
    festa->convidados[convidado].confirmou = 1;
    return 1;
};

float calcularTotalPagamentos(Festa *festa)
{
    float total = 0;
    for (int i = 0; i < festa->totalTrabalhadores; i++)
    {
        total += festa->trabalhadores[i].pagamento;
    }
    return total;
};

// // =====================
// // Funções de Exibição
// // =====================

void mostraConvidado(Convidado c)
{
    printf("\n ------------------------------------- \n");
    printf("\n\t Codigo: %d", c.codigo);
    printf("\n\t Nome do Convidado: %s", c.nome);
    printf("\n\t Telefone: %s", c.telefone);
    printf("\n\t Confirmado: %d", c.confirmou);
    
}

void mostraTrabalhador(Trabalhador t)
{
    printf("\n ------------------------------------- \n");
    printf("\n\t Codigo: %d", t.codigo);
    printf("\n\t Nome do Trabalhador: %s", t.nome);
    printf("\n\t Funcao: %s", t.funcao);
    printf("\n\t Pagamento: R$%.2f", t.pagamento);
}

void mostraConvite(Convite c)
{
    printf("\n ------------------------------------- \n");
    printf("\n\t Convite para: %s ", c.convidado->nome);
    printf("\n\t Mensagem: %s", c.mensagem);
};

void mostraFesta(Festa f)
{
    printf("\n ------------------------------------- \n");
    printf("\n\t Nome da Festa: %s ", f.nome);
    printf("\n\t Local: %s", f.local);
    printf("\n\t Data: %d/%d/%d", f.data.dia, f.data.mes, f.data.ano);
    printf("\n\t Horario: %d:%d", f.horario.hora, f.horario.minuto);
    printf("\n\t Total de Convidados: %d", f.totalConvidados);

    for (int i = 0; i < f.totalConvidados; i++)
    {
        printf("\n\t Convidado %d: %s", f.convidados[i].codigo, f.convidados[i].nome);
    };

    printf("\n\t Total de Trabalhadores: %d", f.totalTrabalhadores);

    for (int i = 0; i < f.totalTrabalhadores; i++)
    {
        printf("\n\t Trabalhador %d: %s", f.trabalhadores[i].codigo, f.trabalhadores[i].nome);
    };

    printf("\n\t Total de Convites: %d", f.totalConvites);
    for (int i = 0; i < f.totalConvites; i++)
    {
        printf("\n Convite codigo %d, para convidado codigo %d: %s", f.convites[i].codigo, f.convites[i].convidado->codigo, f.convites[i].mensagem);
    };
};

void listarConfirmados(Festa f)
{
    for (int i = 0; i < f.totalConvidados; i++)
    {
        if (f.convidados[i].confirmou == 1)
        {
            printf("\n ------------------------------------- \n");
            printf("\n\t Convidado confirmado: %s ", f.convidados[i].nome);
            printf("\n\t Telefone: %s", f.convidados[i].telefone);
        }
    }
};

// // =====================
// // Funções Auxiliares (importante para os alunos)
// // =====================

int buscarConvidado(Festa *festa, int codigo)
{
    for (int i = 0; i < festa->totalConvidados; i++)
    {
        if (festa->convidados[i].codigo == codigo)
            return i;
    }
    return -1;
};

int buscarTrabalhador(Festa *festa, int codigo)
{
    for (int i = 0; i < festa->totalTrabalhadores; i++)
    {
        if (festa->trabalhadores[i].codigo == codigo)
            return i;
    }
    return -1;
};

void liberarMemoria(Festa *festa)
{
    free(festa->convites);
    festa->totalConvites = 0;
};

void menu(Festa *festa)
{
    int opcao;

    do
    {
        printf("\n===== MENU FESTA =====\n");
        printf("1. Cadastrar Convidado\n");
        printf("2. Cadastrar Trabalhador\n");
        printf("3. Criar Convite\n");
        printf("4. Confirmar Presenca\n");
        printf("5. Listar Convidados\n");
        printf("6. Listar Trabalhadores\n");
        printf("7. Listar Confirmados\n");
        printf("8. Mostrar Festa\n");
        printf("9. Calcular Total de Pagamentos\n");
        printf("0. Sair\n");
        printf("Opcao: ");
        scanf("%d", &opcao);

        switch (opcao)
        {
        case 1:
            if (cadastraConvidado(festa))
                printf("Convidado cadastrado com sucesso!\n");
            else
                printf("Erro ao cadastrar convidado!\n");
            break;

        case 2:
            if (cadastraTrabalhador(festa))
                printf("Trabalhador cadastrado com sucesso!\n");
            else
                printf("Erro ao cadastrar trabalhador!\n");
            break;

        case 3:
            if (criarConvite(festa))
                printf("Convite criado com sucesso!\n");
            else
                printf("Erro ao criar convite!\n");
            break;

        case 4:
            if (confirmarPresenca(festa))
                printf("Presenca confirmada!\n");
            else
                printf("Convidado nao encontrado!\n");
            break;

        case 5:
            for (int i = 0; i < festa->totalConvidados; i++)
            {
                mostraConvidado(festa->convidados[i]);
            }
            break;

        case 6:
            for (int i = 0; i < festa->totalTrabalhadores; i++)
            {
                mostraTrabalhador(festa->trabalhadores[i]);
            }
            break;

        case 7:
            listarConfirmados(*festa);
            break;

        case 8:
            mostraFesta(*festa);
            break;

        case 9:
        {
            float total = calcularTotalPagamentos(festa);
            printf("Total de pagamentos: R$ %.2f\n", total);
            break;
        }

        case 0:
            printf("Encerrando sistema...\n");
            break;

        default:
            printf("Opcao invalida!\n");
        }

    } while (opcao != 0);
}