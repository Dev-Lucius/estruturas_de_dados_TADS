#ifndef FESTA_H
#define FESTA_H
#include <stdio.h>
#include <stdlib.h>
#include <locale.h> /*permite acentuação*/

// =====================
// Estruturas
// =====================

typedef struct{
    int dia;
    int mes;
    int ano;
} Data;

typedef struct{
    int hora;
    int minuto;
} Horario;

typedef struct{
    int codigo;
    char nome[100];
    char telefone[20];
    int confirmou; // 0 = não confirmado, 1 = confirmado
} Convidado;

typedef struct{
    int codigo;
    char nome[100];
    char funcao[50];
    float pagamento;
} Trabalhador;

typedef struct{
    int codigo;
    Convidado *convidado;
    char mensagem[200];
} Convite;

typedef struct{
    char nome[100];
    char local[100];
    Data data;
    Horario horario;
    Convidado convidados[50];
    int totalConvidados;
    Trabalhador trabalhadores[20];
    int totalTrabalhadores;
    Convite *convites;
    int totalConvites;
} Festa;

// =====================
// Funções de Cadastro
// =====================

int cadastraConvidado(Festa *festa);

int cadastraTrabalhador(Festa *festa);

int criarConvite(Festa *festa);

// =====================
// Funções de Operação
// =====================

int confirmarPresenca(Festa *festa);

float calcularTotalPagamentos(Festa *festa);

// =====================
// Funções de Exibição
// =====================

void mostraConvidado(Convidado c);

void mostraTrabalhador(Trabalhador t);

void mostraConvite(Convite c);

void mostraFesta(Festa f);

void listarConfirmados(Festa f);

// =====================
// Funções Auxiliares (importante para os alunos)
// =====================

int buscarConvidado(Festa *festa, int codigo);

int buscarTrabalhador(Festa *festa, int codigo);

void liberarMemoria(Festa *festa);

void menu(Festa *festa);
#endif