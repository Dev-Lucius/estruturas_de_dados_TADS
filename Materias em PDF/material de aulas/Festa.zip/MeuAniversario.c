#   include <stdio.h>
#   include <stdlib.h>
#   include <locale.h>
#   include <string.h>
#   include "Festa.h"

int main()
{
    printf("\n****** Inicio da Festa  *******\n");

    Convidado joaquim = {0, "Joaquim", "123456789", 0};
    Convidado joao = {1, "Joao", "456468488", 0};
    Convidado maria = {2, "Maria", "987654321", 0};
    Convidado jose = {3, "Jose", "984194567", 0};
    Convidado pedro = {4, "Pedro", "236646879", 0};
    Convidado paulo = {5, "Paulo", "213135468", 0};

    Trabalhador amanda = {0, "Amanda", "Garçom", 1000};
    Trabalhador jorge = {1, "Jorge", "Garçom", 1000};
    Trabalhador bruna = {2, "Bruna", "Garçom", 1000};
    Trabalhador gabriel = {3, "Gabriel", "Cozinheiro", 1200};
    Trabalhador silvia = {4, "Silvia", "Cozinheira", 1200};

    Data dtAniver = {23, 5, 2026};
    Horario hAniver = {20, 30};

    Festa meuAniver = {"Festa de Aniversario", "Salao Condominio", dtAniver, hAniver};

    meuAniver.convidados[0] = joaquim;
    meuAniver.convidados[1] = joao;
    meuAniver.convidados[2] = maria;
    meuAniver.convidados[3] = jose;
    meuAniver.convidados[4] = pedro;
    meuAniver.convidados[5] = paulo;
    meuAniver.totalConvidados = 6;

    confirmarPresenca(&meuAniver);
    confirmarPresenca(&meuAniver);
    
    meuAniver.trabalhadores[0] = amanda;
    meuAniver.trabalhadores[1] = jorge;
    meuAniver.trabalhadores[2] = bruna;
    meuAniver.trabalhadores[3] = gabriel;
    meuAniver.trabalhadores[4] = silvia;
    meuAniver.totalTrabalhadores = 5;
    
    meuAniver.convites= (Convite*) malloc(50 * sizeof(Convite));
    meuAniver.totalConvites = 1;
    meuAniver.convites[0].codigo = 1;
    meuAniver.convites[0].convidado = &meuAniver.convidados[0];
    strcpy(meuAniver.convites[0].mensagem, "Voce esta convidado para a festa!");


    mostraFesta(meuAniver);
    

    menu(&meuAniver);

    printf("\n****** Fim da Festa  *******\n\n");
    liberarMemoria(&meuAniver);
    exit(0);
}
