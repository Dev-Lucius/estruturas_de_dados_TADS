#include "Festa.h"

// =====================
// Funções de Cadastro
// =====================

// int cadastraConvidado(Festa *festa);

// int cadastraTrabalhador(Festa *festa);

// int criarConvite(Festa *festa);

// void cadastraFesta(Festa *festa);
// incliuir a data, local,

// // =====================
// // Funções de Operação
// // =====================

// int confirmarPresenca(Festa *festa);

// float calcularTotalPagamentos(Festa *festa);

// // =====================
// // Funções de Exibição
// // =====================

void mostraConvidado(Convidado c)
{
    printf("\n ------------------------------------- \n");
    printf("\n Convidado da Festa -- ");
    printf("\n\t Nome:");
    printf("\n\t Telefone:");
    printf("\n\t confirmação:");
    printf("\n ------------------------------------- \n");
}

// void mostraTrabalhador(Trabalhador t);

// void mostraConvite(Convite c);

// void mostraFesta(Festa f);

// void listarConfirmados(Festa f);

// // =====================
// // Funções Auxiliares (importante para os alunos)
// // =====================

// int buscarConvidado(Festa *festa, int codigo);

// int buscarTrabalhador(Festa *festa, int codigo);

// void liberarMemoria(Festa *festa);

void menu(Festa *festa)
{
    int opcao;

    do
    {
        printf("\n===== MENU FESTA =====\n");
        printf("1. Cadastrar Convidado\n");
        printf("2. Cadastrar Trabalhador\n");
        printf("3. Criar Convite\n");
        printf("4. Confirmar Presenca\n");
        printf("5. Listar Convidados\n");
        printf("6. Listar Trabalhadores\n");
        printf("7. Listar Confirmados\n");
        printf("8. Mostrar Festa\n");
        printf("9. Calcular Total de Pagamentos\n");
        printf("0. Sair\n");
        printf("Opcao: ");
        scanf("%d", &opcao);

        // switch(opcao) {
        // case 1:
        //     if (cadastraConvidado(festa))
        //         printf("Convidado cadastrado com sucesso!\n");
        //     else
        //         printf("Erro ao cadastrar convidado!\n");
        //     break;

        // case 2:
        //     if (cadastraTrabalhador(festa))
        //         printf("Trabalhador cadastrado com sucesso!\n");
        //     else
        //         printf("Erro ao cadastrar trabalhador!\n");
        //     break;

        // case 3:
        //     if (criarConvite(festa))
        //         printf("Convite criado com sucesso!\n");
        //     else
        //         printf("Erro ao criar convite!\n");
        //     break;

        // case 4:
        //     if (confirmarPresenca(festa))
        //         printf("Presenca confirmada!\n");
        //     else
        //         printf("Convidado nao encontrado!\n");
        //     break;

        // case 5:
        //     for (int i = 0; i < festa->totalConvidados; i++) {
        //         mostraConvidado(festa->convidados[i]);
        //     }
        //     break;

        // case 6:
        //     for (int i = 0; i < festa->totalTrabalhadores; i++) {
        //         mostraTrabalhador(festa->trabalhadores[i]);
        //     }
        //     break;

        // case 7:
        //     listarConfirmados(*festa);
        //     break;

        // case 8:
        //     mostraFesta(*festa);
        //     break;

        // case 9: {
        //     float total = calcularTotalPagamentos(festa);
        //     printf("Total de pagamentos: R$ %.2f\n", total);
        //     break;
        // }

        // case 0:
        //     printf("Encerrando sistema...\n");
        //     break;

        //         default:
        //             printf("Opcao invalida!\n");
        //     }

    } while (opcao != 0);
}