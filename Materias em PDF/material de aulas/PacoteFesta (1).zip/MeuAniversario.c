
#include "Festa.h"

int main()
{
    printf("\n****** Início da Festa  *******\n");
    Convidado teste;

    mostraConvidado(teste);

    Data dtAniver = {23, 5, 2026};
    Horario hAniver = {20, 30};

    Festa meuAniver = {"Festa de Aniversario", "Salao Condominio", dtAniver, hAniver};

    menu(&meuAniver);

    printf("\n****** Fim da Festa  *******\n\n");
    exit(0);
}
