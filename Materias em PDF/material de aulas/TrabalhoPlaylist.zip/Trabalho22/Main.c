#include <stdio.h>
#include <stdlib.h>
#include "Playlist.h"

int main()
{

    //Escolhi deixar a musica atual acima do menu sempre
    //ao inves de ter que escolher a funcao play para cada uma


    Playlist minhaPlaylist;
    minhaPlaylist.inicio = NULL;
    minhaPlaylist.fim = NULL;
    minhaPlaylist.musicaAtual = NULL;



    Musica musica0 = {1, "Indestructible", "Disturbed", 250};
    inserirMusica(&minhaPlaylist, musica0, 1);
    Musica Musica1 = {2, "Technologic", "Daft Punk", 300};
    inserirMusica(&minhaPlaylist, Musica1, 2);
    Musica musica2 = {3, "Stairway to Heaven", "Led Zeppelin", 300};
    inserirMusica(&minhaPlaylist, musica2, 3);
    Musica musica3 = {4, "still feel", "half alive", 120};
    inserirMusica(&minhaPlaylist, musica3, 4);
    Musica musica4 = {5, "Come as You Are", "Nirvana", 301};
    inserirMusica(&minhaPlaylist, musica4, 5);
    Musica musica5 = {6, "Borderline", "Tame Impala", 200};
    inserirMusica(&minhaPlaylist, musica5, 6);
    Musica musica6 = {7, "Billie Jean", "Michael Jackson", 200};
    inserirMusica(&minhaPlaylist, musica6, 7);
    Musica musica7 = {8, "Break Stuff", "Limp Bizkit", 400};
    inserirMusica(&minhaPlaylist, musica7, 8);
    Musica musica8 = {9, "Purple Haze", "Jimi Hendrix", 250};
    inserirMusica(&minhaPlaylist, musica8, 9);
    Musica musica9 = {10, "Hungry Like the Wolf", "Duran Duran", 150};
    inserirMusica(&minhaPlaylist, musica9, 10);

    executarSistema(&minhaPlaylist);
    return 0;
}