#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "Playlist.h"

void atualizarIDs(Playlist *playlist)
{
    No *musica = playlist->inicio;
    int cont = 1;
    while (musica != NULL)
    {
        musica->dado.id = cont;
        musica = musica->proximo;
        cont++;
    }
}

void inserirMusica(Playlist *playlist, Musica musica, int posicao)
{
    No *novo = (No *)malloc(sizeof(No));
    if (!novo)
    {
        return;
    }
    novo->dado = musica;
    novo->proximo = NULL;
    novo->anterior = NULL;

    if (playlist->inicio == NULL)
    {
        playlist->inicio = playlist->fim = novo;
    }
    else if (posicao <= 1)
    {
        novo->proximo = playlist->inicio;
        playlist->inicio->anterior = novo;
        playlist->inicio = novo;
    }
    else
    {
        No *musica = playlist->inicio;
        int i = 1;
        while (i < posicao - 1 && musica->proximo != NULL)
        {
            musica = musica->proximo;
            i++;
        }
        novo->proximo = musica->proximo;
        novo->anterior = musica;
        if (musica->proximo != NULL)
        {
            musica->proximo->anterior = novo;
        }
        else
        {
            playlist->fim = novo;
        }
        musica->proximo = novo;
    }

    atualizarIDs(playlist);
}

void removerAtual(Playlist *playlist)
{
    if (playlist->musicaAtual == NULL)
    {
        printf("\n[!] Selecione uma musica para remover.\n");
        return;
    }

    No *remover = playlist->musicaAtual;

    if (remover->proximo != NULL)
    {
        playlist->musicaAtual = remover->proximo;
    }
    else if (remover->anterior != NULL)
    {
        playlist->musicaAtual = remover->anterior;
    }
    else
    {
        playlist->musicaAtual = NULL;
    }

    if (remover->anterior != NULL)
    {
        remover->anterior->proximo = remover->proximo;
    }
    else
    {
        playlist->inicio = remover->proximo;
    }

    if (remover->proximo != NULL)
    {
        remover->proximo->anterior = remover->anterior;
    }
    else
    {
        playlist->fim = remover->anterior;
    }

    free(remover);
    atualizarIDs(playlist);
    printf("\nMusica removida com sucesso!\n");
}

void mostrarPlaylist(Playlist *playlist)
{
    No *musica = playlist->inicio;
    while (musica != NULL)
    {
        printf("ID: %d - %s - %s - Duracao: %d\n", musica->dado.id, musica->dado.titulo, musica->dado.artista, musica->dado.duracao);
        musica = musica->proximo;
    }
}

void liberarPlaylist(Playlist *playlist)
{
    No *musica = playlist->inicio;
    while (musica != NULL)
    {
        No *temp = musica;
        musica = musica->proximo;
        free(temp);
    }
    playlist->inicio = playlist->fim = playlist->musicaAtual = NULL;
}

void executarSistema(Playlist *playlist)
{
    char opcao;
    do
    {
        printf("\n========================================");
        if (playlist->musicaAtual != NULL)
        {
            printf("\n Musica atual: %s - %s, Posicao na lista(id): %d", playlist->musicaAtual->dado.titulo, playlist->musicaAtual->dado.artista, playlist->musicaAtual->dado.id);
        }
        else
        {
            printf("\n Nenhuma musica atual");
        }
        printf("\n----------------------------------------");
        printf("\n [1] Play  [2] Avancar  [3] Retroceder");
        printf("\n [4] Inserir  [5] Remover  [6] Mostrar playlist");
        printf("\n [7] Sair");
        printf("\n Comando: ");
        scanf(" %c", &opcao);

        switch (opcao)
        {
        case '1':
            if (playlist->musicaAtual == NULL){
                playlist->musicaAtual = playlist->inicio;
            }
            break;
        case '2':
            if (playlist->musicaAtual && playlist->musicaAtual->proximo){
                playlist->musicaAtual = playlist->musicaAtual->proximo;
            }else{
                printf("\nEssa ja é a ultima musica\n");
            }
            break;
        case '3':
            if (playlist->musicaAtual && playlist->musicaAtual->anterior)
            {
                playlist->musicaAtual = playlist->musicaAtual->anterior;
            }else{
                printf("\nEssa ja é a primeira msusica\n");
            }
            break;
        case '4':
        {
            Musica musica;
            int pos;
            printf("\nInserir musica:\n");
            printf("Titulo: ");
            scanf(" %[^\n]s", musica.titulo);
            printf("Artista: ");
            scanf(" %[^\n]s", musica.artista);
            printf("Duracao: ");
            scanf("%d", &musica.duracao);
            printf("Posicao: ");
            scanf("%d", &pos);
            inserirMusica(playlist, musica, pos);
            printf("\nMusica inserida com sucesso!\n");
            break;
        }
        case '5':
            removerAtual(playlist);
            break;
        case '6':
            mostrarPlaylist(playlist);
            break;
        case '7':
            liberarPlaylist(playlist);
            printf("\n Memoria liberada. Encerrando programa.\n");
            break;
        default:
            printf("\nOpcao invalida!\n");
            break;
        }
    } while (opcao != '7');
}