typedef struct Musica {
    int id;
    char titulo[50];
    char artista[50];
    int duracao;
} Musica;

typedef struct No {
    Musica dado;
    struct No *proximo;
    struct No *anterior;
} No;

typedef struct {
    No *inicio;
    No *fim;
    No *musicaAtual;
} Playlist;

void mostrarPlaylist(Playlist *playlist);
void inserirMusica(Playlist *playlist, Musica m, int posicao);
void atualizarIDs(Playlist *playlist);
void removerAtual(Playlist *playlist);
void liberarPlaylist(Playlist *playlist);
void executarSistema(Playlist *playlist);